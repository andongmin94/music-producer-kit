---
name: lw-ai-tell-audit
description: The pre-delivery AI-tell audit for lyrics (歌词 AI 味诊断). Run this on every draft before it ships. The eight enumerable symptoms that make AI-written lyrics recognisable in one listen, which are machine-countable and which need a person, the diagnostic path from symptom to owning skill, why a draft that passes every check can still be lifeless, and the remediation list. Use when a lyric draft is about to be delivered, when a draft reads fine but feels generic, when deciding whether to accept a version, or when a lyric passed LYR-LINT but still sounds machine-written. AI 味、歌词诊断、验收、太泛、像 AI 写的、交稿前检查。
---

# 歌词 AI 味诊断（AI-Tell Audit）

**每一稿交出去之前都要过这个 skill。这是本库的终检。**

> **核心命题**：AI 写的词不是"用词不好"，是**「没有人做过选择」**。
> 它写出来的四段词语法正确、押韵工整、意象丰富，
> **而这四段可以属于任何一首歌。**

## 按任务读哪几节

| 任务 | 读 |
|---|---|
| 刚写完，要验收 | §2 八条 → §3 |
| "读着没问题但就是泛" | ★ §2（**逐条查，不要凭感觉**） |
| 全过了还是像 AI | ★ §4 |
| 查出问题要改 | §5 |

## 边界

| 不归这里 | 归哪 |
|---|---|
| 规格写完时的检查 | **LYR-LINT 十条**（`lw-workflow` §5.2） |
| 具体怎么改 | 各 L1/L2 skill（§5 给路由） |
| 生成出来的**音频**像不像 AI | **库一** `mc-ai-tell-audit` |

> ★ **与 LYR-LINT 的分工**：
> **lint 问"规格填完没有"，本 skill 问"这词像不像人写的"。**
> **两者都过才算完。** 十条全过的词照样可能满是 AI 味。

---

## 1. 开工前

| 必填 | 问法 |
|---|---|
| **① 这一稿的版本与来源** | AI 直写？skill 引导？手写？**做 AB 时这一栏是全部** |
| **③ 有没有旋律** | 没有的话第 5 条查不了 |

---

## 2. ★ 八条枚举

**逐条打勾。不要凭整体印象。**

| # | AI 味症状 | 对抗的 LYR-SPEC 字段 | 可自动 | 归谁管 |
|---|---|---|---|---|
| **1** | **名词全是抽象的** | `imagery.concrete_nouns` 必填、`forbidden` 黑名单 | ✅ 词性与词表统计 | `lw-imagery` |
| **2** | **结构对称到死** | `asymmetry` 三项必填 | ✅ 每段字数方差 | `lw-structure` |
| **3** | **什么都解决了，没有悬着的** | `narrative.withholding` 必填 | ⚠ 半自动 | `lw-narrative` |
| **4** | **没有视角和时间** | `narrative.pov` ＋ `tense_anchor` | ⚠ 人称代词检测可辅助 | `lw-narrative` |
| **7** | **押韵永远选第一个想到的字** | `rhyme.surprise_notes` | ✅ 韵脚词频 | `lw-rhyme` |
| **8** | **副歌各遍全同，且末遍既没改一字也没加尾**（全同本身在语料里占 27%，不是病） | `asymmetry.chorus_variation` | ✅ 文本 diff | `lw-structure` §6.0 |

★ **八条里六条可算**（第 3、4 半自动）。
**这个比例比库一（十四条里九条）更硬，因为文本不需要检测。**

> ★ **这张表一张三用**：本 skill 的骨架、LYR-LINT 十条的来源、AB 实验评判表的骨架。
> **改一处要同步三处。**

### 2.1 ★ 三条最致命的

**不是因为最难查，而是因为它们读起来都不"错"：**

| # | 为什么致命 |
|---|---|
| **1（名词全抽象）** | ★ **最直接的 AI 指纹**。"时光"、"远方"、"梦"、"自由"——每个都对，合起来是空的 |
| **2（对称到死）** | 四段每段四句、每句七字、句句押韵。**技术上完美，听感上是表格** |
| **3（什么都解决了）** | AI 会把情绪走完整：难过→释怀→祝福。**真人写词经常停在难受里** |

### 2.2 四个立刻能数的粗筛

```bash
# 抽象词命中数 / 具体名词数
# 每段字数方差
# 副歌各遍的文本 diff（★ 只看末遍有没有改动；前两遍相同不算问题）
# 韵脚字的词频排名
```

这四项**人工数**——每项一分钟以内，不需要脚本。

---

## 3. 两个数，不许合并

| | 问什么 | 怎么得 |
|---|---|---|
| **LYR-LINT 通过数** | 规格填完了多少 | 十条 |
| **AI 味旗标数** | 词有多少条机器指纹 | 本 skill 八条 |

```
lint 全过 + 旗标少  → 好，交
lint 全过 + 旗标多  → ★ 规格本身填得像 AI（见 §4）
lint 不过 + 旗标少  → 词不错但规格没写完，补规格（为了可复现）
lint 不过 + 旗标多  → 回 lw-workflow 的 S0
```

---

## 4. ★ 全过了还是像 AI

**这是本 skill 存在的主要理由。**

### 4.1 四个征兆

| 征兆 | 查哪 |
|---|---|
| `intent.one_thing` 念出来**像主题词不像人话** | `lw-song-intent` §2.3 |
| `anchor_object` **说不出颜色和新旧** | ★ `lw-song-intent` §7 的照妖镜——它是倒推出来的，不是从记忆里拿的 |
| 具体名词有了，但**它们不构成系统**（随机堆意象） | `lw-imagery`（`imagery.system` 字段） |
| `asymmetry` 三项填了，但**那些不对称没有理由** | `lw-structure`——★ **为了破坏而破坏，和整齐一样机械** |

★ **共同点**：**规则被当成了要满足的条件，而不是要做的选择。**
这正好就是 AI 味的定义。

### 4.2 一个更狠的测试

> ★ **把这首词的标题和所有专有名词去掉，给一个不知情的人看。**
> **他能说出这首歌在讲哪一件具体的事吗？**
>
> 说不出来 → `one_thing` 没有落到词里，**它只活在规格单上**。

---

## 5. 整改路径

```
读着像 AI
 └─ ① 逐条过 §2 的八条，数出旗标数
 └─ ② 旗标 ≥ 3 → 按下表逐个改
 └─ ③ 旗标 ≤ 2 但仍然像 → §4 的四个征兆
 └─ ④ 还是不行 → ★ 回 lw-song-intent 重答五问
```

### 5.1 症状 → skill

| 症状 | 先查 |
|---|---|
| 空、泛、什么都没说 | `lw-song-intent`（**多半是 `one_thing` 不成立**） |
| 名词都是概念 | `lw-imagery` |
| 读着像散文不像歌 | `lw-structure`（句式的稳定与不稳定） |
| 整齐得像表格 | `lw-structure` 的 `asymmetry` |
| 押韵顺但没意思 | `lw-rhyme` §意外度 |
| 不知道谁在说话 | `lw-narrative` |
| 情绪走完整了，没余味 | `lw-narrative` 的 `withholding` |
| 副歌三遍一模一样、末遍没改一个字 | `lw-structure` §6.0（★ 前两遍相同是常态，别去重写副歌，改末遍一到三个字） |

---

## 6. ★ AB 实验：本库最便宜的那个

> **同一首曲子，三组词：AI 直写 / skill 引导 / 手写，都过 Suno，盲听打乱。**
>
> - **skill 组被听成"人写的"** → 作词库的价值立住
> - **听众仍能把它和手写组分开** → **差的那一截就是接下来要补的规则**

★ **这是整条音频线最便宜的对照实验**——
前半段（读文本盲评）根本不用生成音频。

★★ **评判表必须在看结果之前定稿**，用 §2 的八条当骨架。

**副产品**：一份更新过的 AI 味清单，**直接回填本 skill**。

手写组需要用户提供自己写词的成品（三首即可）。

---

## 7. 交稿前清单

- [ ] **逐条**过了 §2 的八条，**数出了旗标数**（不是凭印象）
- [ ] ★ 做过 §4.2 那个测试：**去掉标题和专名，别人能说出讲的是哪件事**
- [ ] `asymmetry` 的每一处不对称**说得出理由**
- [ ] 具体名词**构成一个系统**，不是随机堆的
- [ ] 副歌各遍**确实不同**，且改动**有意义**（不是换个近义词）
- [ ] 抽象词黑名单**零命中**
- [ ] 如果全过了还是觉得像 AI → **回 `lw-song-intent` 重答五问**，不要在词面上修

---

## 附：来源

- **骨架**来自本库架构 §1.3（AI 味症状 → LYR-SPEC 对抗项对照表）
- 第 2、7、8、9 条只报数，不判过/不过
