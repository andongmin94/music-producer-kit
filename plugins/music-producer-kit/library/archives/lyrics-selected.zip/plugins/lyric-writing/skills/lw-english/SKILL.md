---
name: lw-english
description: The English language layer for lyric writing (英文词的重音与节拍对齐). Word stress is fixed inside a polysyllabic word, so the melody bends to the word and never the reverse; stressed syllables belong on stressed notes, which keeps the natural shape of the language; line length is counted in stressed syllables, not total syllables; common meter and its 4-3 stress lines; long syllables want long notes and the contour should track the sentence's intonation; where the breath falls, how phrase length accelerates a section, what enjambment costs; what gonna, wanna and 'em do to the count; why the, of and and must not land on a downbeat; and the mistakes a Chinese-speaking writer makes in English. Use when writing or checking English lyrics, fitting English words to a melody, when a sung line sounds mispronounced, when counting syllables, or when a line will not fit the bar. 英文作词、英文歌词、重音、节拍对齐、音节数、prosody、phrasing、气口、重音落错、唱不进小节。
---

# 英文词的重音与节拍对齐（English Stress & Prosody）






★ **本 skill 只管一件事：英文的重音、音节与气口怎么和音乐咬合。**
押韵去 `lw-rhyme`，段落结构去 `lw-structure`。

## 按任务读哪几节

| 你要做的 | 读 |
|---|---|
| 一行词到底怎么和拍子对上 | ★ §1 地基规则 ＋ §1.3 三步标重音 |
| 某个词的重音能不能挪 / 强拍上该放什么词 | ★ §2.1（**不能**）、§2.2–§2.3 |
| 一串单音节词读起来像敲钉子 / `gonna` 算几个音节 | §2.4、§2.5 |
| **一行"多长"到底怎么数** | ★ §3（**数重音，不数音节总数**） |
| 词和旋律合不合 | ★ §4 prosody |
| 气口在哪、句子能不能跨行 | §5 |

| 填 LYR-SPEC 的 `prosody.*` | §8 |
| 音步表、重音标记法、省音全表、节奏大纲 | [reference.md](reference.md) |

## 边界

| 不归这里 | 归哪 |
|---|---|
| **押韵的类型学、韵式、意外度、故意不押** | ★ `lw-rhyme`（**本 skill 一条韵型都不列**）；语音家族表与元音三角形在它的 [reference.md](../lw-rhyme/reference.md) |
| 这首歌要说什么 | `lw-song-intent` |
| 意象、具体名词、object writing | `lw-imagery` |
| **行数、段落功能、平衡与不平衡、hook 放哪** | ★ `lw-structure`（本 skill 只管**怎么数一行有多长**，不管**用这个长度做什么结构**） |
| 人称、视角、时间锚点、留白 | `lw-narrative` |



| **rap 的 flow、重音堆叠、切分与抢拍** | ★ `lw-rap`（本 skill 讲的是"唱"的重音对齐，不是 flow） |
| 日文モーラ・符割り | `lw-japanese`（**别用英文重音顶替**） |
| **韩文받침、音节计数、连音与音变** | ★ `lw-korean`（韩英混写的那一半按本 skill 这套过，见 lw-korean §7） |
| 旋律本身怎么写、怎么改、最高音定在哪 | **库一** `mc-melody` |
| 那些字该怎么唱（气声、力度、咬字、修音） | **库一** `mc-vocal-direction` |

---

## 1. ★ 地基规则：重读音节配重拍

### 1.1 规则本身

> **Stressed syllables belong with stressed notes.**
> **Unstressed syllables belong with unstressed notes.**
> （Pattison《Writing Better Lyrics》"The Rhythms of the Lines" 一节）

Pattison 给这条规则起的名字是 **preserving the natural shape of the language**——
**保住语言自己的形状。**
**它为什么成立**：英文的每个词自带一条高低起伏的轮廓，听众靠那条轮廓认词；旋律又派了一条。
**两条同向 → 听众不费力；反向 → 听众得先把词"翻译"回来才能理解意思。**

★ **注意这条规则的方向**：**它约束的是"把哪个音节放到哪个音符上"，不约束旋律该怎么写。**
旋律的强弱格是既定的（先曲后词），或由你写的重音排列反推出来（先词后曲）——
**变量永远是词的落位，不是词的读音。**

**另外两家独立说了同一件事——三家一致，可以当硬约束用**：
★ **歌词在配乐之前就已经有自己的节奏**，英语天然给某些词更大的重音；
**匹配规则：非重读音节不应落在音乐中带强调的时刻**
（《Lyrics: Writing Better Words for Your Songs》p0100）。
★ **好的 prosody 意味着"词是按我们说话的方式被唱出来的"——Don't warp the words**
（Davis《Craft of Lyric Writing》p0259）。

★★ **Davis 给了一个极好用的终检口令**（同 p0259）：

> **"When you read the words, the music plays."**
> **当你只读这些词的时候，音乐自己就响起来了。**

**用法**：把一段词**当散文念一遍**，念出来的轻重缓急**就是旋律的轻重缓急** → 这一段对齐过了。

### 1.2 错位的三种后果

- **词内重音被推到弱音节上** → ★ **像念错词**，听众会觉得歌手英语不好
  （`PER-fect` 唱成 `per-FECT`；`HAP-pi-ness` 唱成 `hap-PI-ness`）
- **功能词被顶上强拍** → ★ **句子的重心跑到没有内容的字上**，整句听起来虚
- **重音过密（相邻音节都重）** → 步子被打断，时间被拉长（见 §2.4）

★★ **第一种最贵**：押韵押错了是"不够好"，**重音错了是"错"**。
听众未必说得出哪里不对，但会觉得这首歌"不像母语的人写的"。

### 1.2b ★ 还有第四种后果：重音会改变句子的意思

Davis《Craft of Lyric Writing》p0260 用一句话演示：

```
YOU don't want me anymore     —— 别人还要我，只有你不要
you DON'T want me anymore     —— 在争辩，否认对方的否认
you don't WANT me anymore     —— "不想要"这个状态变了
you don't want ME anymore     —— 你要的是别人
you don't want me ANYMORE     —— 以前要，现在不要了
```

**同一串词，重音落点不同，意思完全不同。**

> ★ **Davis 的规则（p0260）：你想强调的那个词，必须落在 stressed note 上。**





**自检动作**：把一行词**用不同的重音各念一遍**，确认你选中的落点说出的正是你想说的那句话。

### 1.3 ★ 自检动作：三步标重音

**这是本 skill 唯一一个必须机械做完的动作。**

```
第 1 步  把这一行【说】出来（不是唱），在每个重读音节上画 /
         —— 说的时候旋律不在场，词自己的形状才露出来
第 2 步  标出强拍位置（4/4 里通常是 1 和 3，切分另算）
第 3 步  两行对齐，逐个看 / 有没有落在强拍上
```

**判读**：全部对上 → 通过。
**实词重音落在弱位、但那个词不重要** → 可以接受，不是每个重音都必须上强拍。
★ **多音节词的词重音落在弱位** → **必须改**（换词，或把整个词平移一个音符）。
★ **功能词占了强拍** → **必须改**（见 §2.3 的四种改法）。

**失效条件**：
- ★ **故意的切分（syncopation）把重音推离强拍，是手段不是错**——
  前提是**推走的是句重音而不是词重音**，且**整段一致**
- **说唱**里重音排布是 flow 的一部分 → `lw-rap`；
  **极快的音符**（一拍四个以上音节）上强弱差别本来就听不太出来

---

## 2. ★ 英文的重音不是你能选的

英文的词重音不可改，句重音可调。完整规则（词性换重音、英美差异、次重音、功能词落强拍的四种改法、单音节连用的扬扬格、缩写与省音、多音节词的坑）见 [reference.md](reference.md)。

**最要紧的一条**：多音节词的重音位置是词典定死的，写不进强拍就换词，不要指望唱的人迁就。

## 3. ★ 一行"多长"：数重音，不数音节总数

### 3.1 规则

> **Line length is the traffic cop in your lyric.**
> **长度由重读音节的数量决定，而不是音节总数。**
> **重音数量直接决定这一行要占几小节。**
> （Pattison《Writing Better Lyrics》"Length of Lines" 一节）






```
I HITCHED to TUL-sa WORN and SOAKED        4 重音
The WAI-tress STARED be-FORE she SPOKE     4 重音
Sá-tan RIDES the FREE-way …                3 重音 + 收尾弱音节（记作 3+）
```

### 3.1b ★★ 更精确的说法：对齐的单位是**拍数**

Davis 把同一件事说得更狠，而且给出了可执行的门槛：

> **在各段共用同一条旋律的歌里（AAA 型），必须让各段的重音拍一致；
> 音节数不必相同，但拍数必须相同。**
> （Davis《Craft of Lyric Writing》p0228。实例：《By the Time I Get to Phoenix》
> 第一行 4 个音节、第二三行 5 个音节——**音节数不等，拍数完全匹配**。）




★ **调节的办法在同一处（p0229）**：**靠增减非重读音节的数量保持拍数一致**，
同时**避开 sing-song effect（单调的吟唱感）**。

**自检动作**：把同一旋律的各段**竖着排**，逐行只标重音拍，看拍数列是否完全对齐。
★ **只对音节数不算过。**

### 3.2 `3+` 与 `2+` 的记法

**一个 4 重音的行可以缩成"3+ 重音"**：**三个重音，末尾再挂一个弱音节收尾**
（例：`Sátan rídes the fréeway`）。
★ **关键判断：`3+` 仍然比纯 `3` 长**，所以 longer / shorter 的对比关系**保住了**
（Pattison《Writing Better Lyrics》"Common Meter 的变体" 一节）。
**用法**：一行需要"比三重音长一点、但不到四重音"时用 `3+`；
在 LYR-SPEC 里照记，**不要四舍五入成 3 或 4**。

### 3.3 Common meter：英文最基础的那个格子

```
第 1–2 小节   4 重音   DUM da DUM da DUM da DUM
第 3–4 小节   3 重音   DUM da DUM da DUM
第 5–6 小节   4 重音
第 7–8 小节   3 重音
```

- **八小节系统**是西方流行音乐的基础单元，拆成 2 小节与 4 小节两级；**节奏模式是 长/短/长/短**
- ★ **心理效应**：第 4 小节末**感觉不平衡、必须继续**；第 8 小节末**感觉稳**
- ★ **重音强度本身可以弱（wimpy stresses）**，仍然算一个重音位

（以上均见 Pattison《Writing Better Lyrics》"Common Meter 与八小节结构" 一节。）

★ **别名**：《Lyrics: Writing Better Words for Your Songs》p0100 叫它 **Ballad metre（民谣格律）**。
**Meter** 源自希腊语 *metron*，意为 **"measured rhythm"**；多数流行歌是 4/4（common time），
**第一拍的重音叫 downbeat**（Davis《Craft of Lyric Writing》p0227）。
★★ **三家举的例子都是《Amazing Grace》**——**它是英文 4-3-4-3 的标准参照，背下来当尺子用。**

★★ **Common meter 是起点和工具，不是目标**：用它建立的预期去制造惊喜（Pattison 同节）。

**失效条件**：**三拍子、6/8、以及大量切分的现代节奏**里，"一个重音 ≈ 半小节"的换算不成立——
**这时只能回到"每个重音落在哪个具体音符上"去数。**

### 3.4 长短关系：只讲重音这一侧

> **Longer followed by shorter is less stable than shorter followed by longer.**
> **长行后接短行，比短行后接长行，向前倾斜得厉害得多。**
> （Pattison《Writing Better Lyrics》"Stability vs. Instability: Two-Line Sections" 一节）

★ **四种两行组合的稳定度排序与这条法则的原理在 [reference.md](reference.md) §5。**
**行长和押韵是两个独立的工具**：本 skill 只负责"行长"，"押韵"在 `lw-rhyme`，
**两维的组合怎么做段落**在 `lw-structure`。

---

## 4. ★ prosody：词与音乐互相支持

### 4.1 定义

> **Prosody ＝ "appropriate relationship between elements, whatever they may be."**
> **元素之间恰当的关系——不论那些元素是什么。**
> Pattison 把它接到亚里士多德的**统一性（unity）**上：**unity 的另一个说法就是 prosody。**
> （Pattison《Writing Better Lyrics》"Prosody：结构作为电影配乐" 一节）

★ **prosody 不是一条规则，是一个判据**：
**问"这两个元素在互相支持吗"，而不是问"这样写对不对"。**

### 4.2 四个层面（Pattison 同节）

- **Words and music**：小调支持或造出悲伤感 → 旋律/和声归**库一**
- ★ **Syllables and notes**：**重读音节与重音音符的关系**；对齐时**旋律形状匹配语言的自然形状**
  → ★ **本 skill §1 的全部**
- ★ **Rhythm and meaning**：意思要"停"，节奏就真的停（`you gotta stop! …（停）… look and listen`）；
  写奔马就用三连音的感觉 → ★ **本 skill §5**
- **Structure and emotion**：结构的运动支持情绪 → `lw-structure` ＋ `lw-rhyme` §3

★ **第二、三条是本 skill 的工作范围；第一、四条只在这里点一下去处。**

### 4.3 ★ Stable / Unstable 是最实用的那把尺

Pattison 的操作方法是先问一个问题：

> **"Is the emotion in this section stable or unstable?"**
> **这一段的情绪是稳的还是不稳的？**

一旦答了，**其余选择（想法、旋律、节奏、和弦、词的结构）就都有了判据。**
**落到本 skill 这一侧**：**稳** → 节奏规律（一路 `da DUM`）、行长匹配、重音数整齐；
**不稳** → ★ **优先动行长**（长短不匹配），**其次才动节奏**。

★★ **最反直觉、也最值钱的一条：不稳的段落，节奏往往要写得很规律。**

Pattison 分析 Gary Burr "Can't Be Really Gone" 第一段：奇数行（5 行）、
行长 4-4-4-3-3（不平衡），**整段情绪是不稳的；但节奏极其规律**——
五行几乎全是 `Da DUM da DUM da DUM da DUM`。
★ **理由**：**所有东西都失衡的话，就没有稳定的东西让不稳定元素去摩擦（rub against）**；
节奏一乱，**行长的差别就变得不清晰，因此不再有效**。

> ★ **推论（可以当规则用）**：**一段里同时能动的不稳定因素，最好只有一两个。**
> 规律的节奏是背景，**行长的变化才看得见**。

**自检动作**：一段写完，列出它的不稳定因素（奇数行数 / 行长不匹配 / 节奏不规则 / 韵不稳）。
**超过两项 → 挑一项还原成规律的**，通常先还原节奏。

#### ★ 两家在这里说法不一致——并排保留

| 出处 | 说法 |
|---|---|
| **Pattison**《Writing Better Lyrics》"Can't Be Really Gone" 分析 | ★ **规律的节奏是背景稳定性**，正因为它规律，行长的不平衡才"看得见"。**不稳的段落往往要配规律的节奏** |
| **Davis**《Craft of Lyric Writing》p0229 | ★ **"完美的格律规律性不是优点，反而是缺陷（flaw）"**——过于精确的交替会变得机械。段内要主动制造变化 |

★ **分歧点在"规律"指的是哪一层**：
Pattison 说的是**整段的节奏底盘**（`da DUM` 的步子不乱），
Davis 说的是**行与行完全一模一样的复制**（到了机械的程度）。

**调和用的操作口径（Davis p0230）**：**① 改变重音 ② 改变行内的自然停顿 ③ 改变标点**——
★ 这三样都能**在不动节奏底盘的前提下**破掉机械感，**先用这三样**。
Davis 给这件事起的名字是 **meter fatigue（格律疲劳，p0245）**。
★ **展开与更贵的解法见 [reference.md](reference.md) §6。**

### 4.4 长音节配长音符，元音要经得起拉

**说话的时候没人把一个音节拖满四拍，音乐经常这么干**
（Pattison《Writing Better Lyrics》"Rhythm of Lines" 一节）。

★ **后果**：**落在长音符上的那个音节，它的元音会被放大**——
在押韵那一侧的表现是"音符越长，加音韵里多出的辅音越藏得住"（→ `lw-rhyme` §3.4）；
**在本 skill 这一侧的表现是可唱性。**

- **全段最高音落点**：★ 必须是**重读音节**，且元音开放、好唱
- **拖长的尾音**：同上。★ 闭口元音、`-ist` `-sks` 这类辅音串**拖不动**
- **跨换声点的音**：用越靠元音三角形顶点的元音越好唱；双元音要看**保持哪一半**

★ **元音的开放度与可唱性排序在 `lw-rhyme` 的 [reference.md](../lw-rhyme/reference.md) §6**，
本 skill 不重复，只强调**它必须与重音落点同时满足**：
**一个好唱的元音落在弱音节上，等于没用。**

**两条可以直接执行的补充**：

- ★ **"长元音的词好唱得多；如果一个词你拉不住（can't hold out），就去找替代词。"**
  （《Lyrics: Writing Better Words for Your Songs》p0100，引 Tony Asher）
  ——**这是换词的判据，不是修辞建议**
- ★ **旋律以三个长音收尾（`TUM TUM TUM`）时，不要拿一个三音节词去填**
  （`rev-er-IE`、`ten-der-LY`），**除非重音完全吻合**（Davis《Craft of Lyric Writing》p0259）。
  这是 §2.1 的直接后果：三音节词只有一个重音，硬填进三个等重的长音，**另两个音节会被迫加重**

**自检动作（Davis p0259）**：★ **边写边唱，不要边写边看。**
唱一遍同时检 sense（意思）、sound（声音）、singability（可唱性）三项。

### 4.5 旋律走向与句子自己的语调

英文句子有自己的语调轮廓，最硬的三条：

- **陈述句**句末**降**——顺着降，或**故意不降**（不降＝"话还没说完"，用来把一段推进下一段）
- **一般疑问句（yes/no）**句末**升**——★ 旋律在这里强行下行，"提问"会变成"自言自语"
- **特殊疑问句（wh-）**句末**降**——★ 和一般疑问句相反，**别一见问号就往上写**




★ **还有一条独立的轴，而且更容易执行**（Davis《Craft of Lyric Writing》p0260）：

> **上升的情绪配上升的旋律**（`high on a hill`）；**下降的情绪配下降的旋律**（`down in the dumps`）。

**语调轴跟的是句型，语义轴跟的是那件事本身的方向（上/下、扩张/收缩、明/暗）。
两轴冲突时先保语义轴**——听众记得住的是画面的方向，不是语法的语气。

**失效条件**：**旋律的动机与和声进行常常压过语调**——这两条都是"能顺就顺"，
**不是像 §1 那样的硬约束**。改不动时**优先保 §1 的重音对齐。**
★ **反向用法（Davis p0257）**：故意与音乐反着来也是手法——
把《Happy Days Are Here Again》放慢就成了 "unhappy days"；前提同样是听众听得出你是故意的。

---

## 5. phrasing、气口与跨行

### 5.1 一行 ＝ 一个乐句 ＝ 一个气口

★ **在 LYR-SPEC 里，分行不是排版，是指令**——后端会把换行当乐句边界读
（见 `lw-workflow` 的 LYR-SPEC 定义 §1.8）。

**所以英文词的分行必须同时满足三件事**：
**① 是一个语法上说得通的短语**（不是随手断开）；**② 唱得完一口气**；
**③ ★ 和 `prosody.sections[].syllables` 的那个数字对得上**。

**自检动作**：**一口气把一行唱完，唱不完就是太长了。**
不要靠"歌手能换气"糊弄过去——换气点会被听见。

### 5.2 ★ 短语长度是加速器和刹车

Pattison 在 "Form Follows Function" 一节里把 prosody 的操作工具列成三样：
**phrase lengths（短语长度）、rhythms（节奏）、rhyme schemes（韵式）。**
第三样归 `lw-rhyme`，前两样在本 skill。

- **加速**（情绪强烈处）：★ **短短语** ＋ 紧密的韵（连续韵、内韵）。
  Pattison 的比喻：**韵是油门，踏板踩得越深车开得越快**
- **减速**：★ **加长短语** ＋ 把韵摊进规律的模式。比喻：**后备降落伞弹出来了**

★ **失配的代价**（Pattison 的 Ping-Pong 示例）：把短语拉长、韵摊成规律的 `a-b-a-b-a-b` 之后，
**"结构变成一辆慢吞吞的老面包车，而意思还在梦想大奖赛的方格旗。Bad combination."**

**实例（Beth Nielsen Chapman "Years"，Pattison 同节）**：
**Verse 各行 6, 5, 6, 5, 9, 9 重音**——长行，**徘徊、放松**，和那个女儿一样；
**Chorus 各行 3, 3, 2, 2, 2**——短行，**加速**，说的正是"岁月过得多快"。
★ **最后两行的 2 重音在音乐上只占 1 小节**——**词的 prosody 被音乐坐实了。**

### 5.3 气口放在哪

- **行末**：默认气口。★ 行末若同时押韵，停得最实（→ `lw-rhyme` §3）
- **行中的语法停顿**（逗号、从句边界）：★ **可以当"迷你气口"做节奏上的强调**
- ★ **不该有气口的地方出现气口**：冠词与名词之间、介词与宾语之间断开 → 听起来像唱错了

**自检动作**：★ **按你写的分行念给别人听，问他刚才那句话是什么意思**；
需要你解释断在哪 → 分行错了。

### 5.4 跨行（enjambment）

**定义**：一个句子的意思跨过行末继续，行末没有语法上的完结。

- **它做什么**：★ **阻止闭合**，把听众推向下一行；让规整的格子听起来不那么方
- **代价**：★ **削弱行末的 HOT SPOT**——韵脚位置的聚光灯被"话没说完"抵消掉一部分
  （→ `lw-rhyme` §1）；用多了**段落边界会糊**，听众数不清这段有几行

★ **和"故意不押"是两种独立的开门手段，可以叠加也可以分别用**：
**不押断的是声音的预期**（→ `lw-rhyme` §7）；**跨行断的是语法的完结**（本节）。

★ **Davis 管它叫 run-on line，比喻是"wrapping a thought around a corner"——
把一个想法绕过转角**，功能是**软化格律的严格性**（《Craft of Lyric Writing》p0230）。
★★ **同时给了最硬的那条限制（p0231）：必须省着用（sparingly）——
听众要费力才跟得上绕弯的思想，连着用会令人疲惫。**

**自检动作**：每一处跨行问一句——**"如果这里把话说完，会损失什么？"**
答不上来 → 那不是跨行，是句子没安排好。

**失效条件**：
- **副歌**里慎用。副歌要的是能被记住、能被跟唱的完整短句
- ★ **标题所在的那一行永远不跨行**——标题必须自己站得住
- ★ **一段里连着两处以上的跨行**，通常已经过量（Davis p0231）

### 5.5 节奏的规律与变异

**规律节奏创造稳定的运动，不规则节奏创造较不稳定的运动；
两行节奏匹配创造稳定，不匹配创造不稳定。**
（Pattison《Writing Better Lyrics》"The Rhythms of the Lines" 一节）

★ **第一行的责任最重**：**首行用它的节奏和长度设定标准**，后面所有行都被它比着听——
**首行是全段最不该将就的一行。**

**自检动作**：把每一行的节奏写成 `da DUM` 串**逐行对齐看**。
全部一样 → 稳，**但要确认这段情绪也是稳的**（§4.3）；
只有一行不一样 → ★ **那一行就是被聚光灯照到的位置**，确认它值得。

---















































## 8. 与 LYR-SPEC 的字段对应

| 字段 | 英文词怎么填 |
|---|---|
| `prosody.sections[].syllables` | ★ **填音节数**（一个元素 ＝ 一行）。**同时在 `notes` 里记下这一行的重音数**——★ **决定小节数的是重音数**（§3.1、§3.1b） |
| `prosody.sections[].stress_positions` | ★ 本 skill 的主字段。**重音落在第几个音节**。`3+` 照写，不四舍五入（§3.2） |
| `prosody.sections[].peak_syllable` | ★ **必须是重读音节**，且元音开放、经得起拉长（§4.4） |
| `prosody.sections[].melody_contour` | 与句子语调、与意思方向的关系写在这里（§4.5） |
| `prosody.sections[].notes` | ○ 有 MIDI 序列时，用它核对 §1.3 第 2 步的强拍位置 |
| `lyrics[].lines` | ★ **分行 ＝ 气口 ＝ 乐句边界**（§5.1）。跨行的地方在 `note` 里写理由（§5.4） |
| `asymmetry.short_line` | ★ 用**重音数**说"短"，不要用音节数 |
| `rhyme.*` | 全部归 `lw-rhyme`。★ **本 skill 不填韵的任何字段** |
| `checks.self_audit` | §9 的清单逐条过 |




---

## 9. 收工自检

- [ ] ★ 每一行做过 **§1.3 三步标重音**；★ **只读词就能听见音乐**（§1.1）
- [ ] ★ 每一行**选中的重音落点，说出的正是你想说的那句话**（§1.2b）
- [ ] **没有多音节词的词重音落在弱位**；三音节以上的词逐个念过（§2.1）
- [ ] ★ **强拍列测试做过**，读得出这首歌在讲什么；没有功能词占强拍（§2.3）
- [ ] 音步（spondee / anapest）**和这段情绪同向**（§2.4）
- [ ] ★ `gonna` / `'em` 处**改回全写念过**，确认是口语不是凑数；语域全曲一致（§2.5）
- [ ] 一行里最要紧的意思**没有落在这行最后一个弱音节上**（§2.6）
- [ ] ★ **行长按重音数记**，不是音节总数；`3+` 没有四舍五入（§3.1、§3.2）
- [ ] ★★ **分节歌各段的拍数逐行对齐过**（只对音节数不算过）（§3.1b）
- [ ] ★ 这段情绪是稳是不稳**答得出来**；不稳定因素**不超过两项**（§4.3）
- [ ] ★ **最高音落在重读音节上**，且元音经得起拉长（§4.4）
- [ ] 疑问句的旋律走向没有反着写；升降的意思配了升降的旋律（§4.5）
- [ ] ★ **每行一口气唱得完**；气口没断在冠词与名词、介词与宾语之间（§5.1、§5.3）
- [ ] 段落的加速/减速（短语长度）**和这段情绪同向**（§5.2）
- [ ] 每处跨行**说得出理由**；**标题行没有跨行**；一段里跨行不超过两处（§5.4）
- [ ] 逐行 `da DUM` 串对齐看过；不一样的那一行**值得被照亮**（§5.5）



---

## 附注：功能词的两条并排

本 skill 说功能词不许占强拍。Stolpe 从另一侧补一条，两条不矛盾（《Popular Lyric Writing》p0006、p0010）：
**连词与介词有时强到能在段落内部制造"停顿与启动"的感觉**，加进去词会更像人在说话；
但**这些停顿启动必须对上音乐乐句的起止**，对不上就又成了断句与旋律错位。
所以做法是：先用它们把句子说顺，再按乐句重新连接，最后查它们落没落在强拍上。

## 附：来源

















